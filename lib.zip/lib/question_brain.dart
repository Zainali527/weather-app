import 'package:rflutter_alert/rflutter_alert.dart';

import 'question.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
// Encapsulation safe our data from other to do changes
// In dart by using underscore in start of our property in class (like _data)class we actually make our property private , we are Encapsulating (private) the property only class object can access that property
int _number = 0;
class QuestionBrain {
  List<Questions> _data = [
    Questions(
        ques: 'You can lead a cow down stairs but not up stairs.', ans: false),
    Questions(ques: 'Aproximately one quater of human bones are in the feet.',
        ans: true),
    Questions(ques: 'A slug\'s blood is green.', ans: true),
    Questions(ques: 'Your name is Zain', ans: true),
    Questions(ques: 'Pegion can fly', ans: true),
    Questions(ques: 'Car can run on water', ans: false),
    Questions(ques: 'Human ancestors are monkey', ans: false),
    Questions(ques: 'Your are millionaire', ans: false),
  ];

  String Q_text() {
    return _data[_number].ques;
  }

  bool Q_ans() {
    return _data[_number].ans;
  }

int return_length(){
    int length = _data.length;
    print('return lenth is $length');
    return _data.length;
}
  void change_number() {
    _number ++;
    if (_number == _data.length) {
      _number=0;
    }
  }
}
