class Story {
  String text;
  String choice1;
  String choice2;
  Story({
    required this.text,
    required this.choice1,
    required this.choice2,
  });
}