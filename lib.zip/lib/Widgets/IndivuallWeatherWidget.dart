import 'dart:ui';

import 'package:course/BMI_components/Const_varibles.dart';
import 'package:course/Weather/screens/WidgetConstant.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
class HourlyWeather extends StatefulWidget {
  Color? colour;
  final String? weather_condition;
  final double? slotHeight;
  final double? slotWidth;
  HourlyWeather({this.colour, this.weather_condition, this.slotHeight, this.slotWidth});

  @override
  State<HourlyWeather> createState() => _HourlyWeatherState();
}
Color? color;
class _HourlyWeatherState extends State<HourlyWeather> {
  @override
  Widget build(BuildContext context) {
    return Flexible(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: GestureDetector(
          onTap: (){
            setState(() {

            });
            // Navigator.push(context, MaterialPageRoute(builder: (context)=>move()));
          },
          child: Container(
            height: widget.slotHeight?? 110,
            width: widget.slotWidth?? 97,
            decoration: BoxDecoration(
              color: color ?? widget.colour,
              borderRadius: BorderRadius.all(Radius.circular(30.0)),
              border: Border.all(color: kMain_color,width: 2,style: BorderStyle.solid),
              boxShadow: [
                BoxShadow(
                  color: kSecondary_color.withOpacity(0.3),
                  spreadRadius: 1.7,
                  blurRadius: 7.0,
                  offset: Offset(2.0,3.0), // Shadow below the container
                ),
              ],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Text('11:00', style: kSmall_text_light),
                Image(image: AssetImage('images/dayfewclouds.png'),height: 60,),
                Text('42°/27°', style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.w500),),
              ],
            ),
          ),
        ),
      ),
    );
  }
}