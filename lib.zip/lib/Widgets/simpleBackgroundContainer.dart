import 'package:flutter/material.dart';
import 'package:course/Weather/screens/WidgetConstant.dart';
class BackgroundContainer extends StatelessWidget {
  final double? ContainerHeight;
  final Widget? childWidget;
  BackgroundContainer({ this .ContainerHeight , this.childWidget});

  @override
  Widget build(BuildContext context) {
    return Flexible(
      child: Container(
        padding: EdgeInsets.all(8),
        height: ContainerHeight,
        decoration: BoxDecoration(
          color: kSecondary_color,
          borderRadius: BorderRadius.all(Radius.circular(40.0)),
        ),
        child: childWidget,
      ),
    );
  }
}