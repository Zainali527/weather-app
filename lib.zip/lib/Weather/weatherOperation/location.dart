import 'package:geolocator/geolocator.dart';

class location {
  double? Longitude;
  double? Latitude;

  Future<void> Location() async {
    LocationPermission permission = await Geolocator.checkPermission();
    try {
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        print(" Permission = $permission");
      }
      if (permission == LocationPermission.whileInUse ||
          permission == LocationPermission.always) {
        Position position = await Geolocator.getCurrentPosition(
            desiredAccuracy: LocationAccuracy.high);
        // print("Position = $position");
        Longitude = position.longitude;
        Latitude = position.latitude;
      } else {
        print("Location permission denied");
      }
    } catch (e) {}
    ;
  }
}
