import 'package:course/Weather/screens/search_city_screen.dart';
import 'package:course/Weather/weatherOperation/networking.dart';
import 'package:course/Weather/weatherOperation/location.dart';
import 'package:course/Weather/weatherOperation/Model.dart';

// const apiKey = '1a6fa5d9f779320433fdd46633a84fb9';
// const openweathermap = 'https://api.openweathermap.org/data/2.5';
//-----------------search city api-------------------//

// const City = 'Multan';
class weathersetting {
  // Future<dynamic> SearchbyCity(String city) async{
  //   var url  = 'http://api.weatherapi.com/v1/forecast.json?key=d35a71969a8c456da3e224145242206&q=$city&days=7&aqi=no&alerts=no&alerts';
  //   Network net = Network(URL: url);
  //   print(url);
  //   var cityWeatherData = await net.GetApiData();
  //   print('weatherdata is $cityWeatherData');
  //   return cityWeatherData;
  // }
  var Starting_City_Name = 'Multan';
  var finalCity;

  Future<dynamic> GetAlldata(City) async {
    dynamic AllData;
    if (City != null) {
      print(
          'http://api.weatherapi.com/v1/forecast.json?key=d35a71969a8c456da3e224145242206&q=$City&days=7&aqi=no&alerts=no&alerts');
      Network network = Network(
        URL:
            'http://api.weatherapi.com/v1/forecast.json?key=d35a71969a8c456da3e224145242206&q=$City&days=7&aqi=no&alerts=no&alerts',
      );
      AllData = await network.GetApiData();
    } else {
      // print('http://api.weatherapi.com/v1/forecast.json?key=d35a71969a8c456da3e224145242206&q=$Starting_City_Name&days=7&aqi=no&alerts=no&alerts');
      print(
          'http://api.weatherapi.com/v1/forecast.json?key=d35a71969a8c456da3e224145242206&q=$Starting_City_Name&days=7&aqi=no&alerts=no&alerts');
      Network network = Network(
        URL:
            'http://api.weatherapi.com/v1/forecast.json?key=d35a71969a8c456da3e224145242206&q=$Starting_City_Name&days=7&aqi=no&alerts=no&alerts',
      );
      AllData = await network.GetApiData();
    }
    // print('New api all DATA  ===== $AllData');
    return AllData;
  }
}

// ---------OLD API SETTING----------//
// // -------------forecast api--------------//
// Future<dynamic> Getforecastdata()async{
//   location data= location();
//   await data.Location();
//   double? longi = data.Longitude;
//   double? lati = data.Latitude;
//   print('$openweathermap/forecast?lat=$lati&lon=$longi&appid=$apiKey&units=metric');
//   Network network = Network(URL: 'https://api.openweathermap.org/data/2.5/forecast?lat=${data.Latitude}&lon=${data.Longitude}&appid=$apiKey&units=metric',);
//   var forecastdata = await network.GetApiData();
//   // print('FORECAST DATA in weathersetting ===== $forecastdata');
//   return forecastdata;
// }
//
//   //-------------weather api--------------//
//   Future<dynamic> GetweatherData()async{
//     location data= location();
//     await data.Location();
//     double? longi = data.Longitude;
//     double? lati = data.Latitude;
//     print('$openweathermap/weather?lat=$lati&lon=$longi&appid=$apiKey&units=metric');
//     Network network = Network(
//         URL: 'https://api.openweathermap.org/data/2.5/weather?lat=${data.Latitude}&lon=${data.Longitude}&appid=$apiKey&units=metric'
//     );
//     var weatherdata = await network.GetApiData();
//     print('WEATHER DATA in weathersetting ===== $weatherdata');
//     return weatherdata;
//   }
//
// class WeatherModel {
//   String getWeatherImage(int condition) {
//     if (condition < 300) {
//       return 'images/thunderstrom.png' ;
//     } else if (condition < 400) {
//       return 'images/drizzling.png';
//     } else if (condition < 600) {
//       return 'images/rain.png';
//     } else if (condition < 700) {
//       return 'images/snow.png';
//     } else if (condition < 800) {
//       return 'images/mist.png';
//     } else if (condition == 800) {
//       return 'images/sun.png';
//     } else if (condition <= 804) {
//       return 'images/dayfewclouds.png';
//     } else {
//       return '🤷‍';
//     }
//   }
//   String getWeatherDescription(int condition) {
//     if (condition == 200) {
//       return 'thunderstorm with light rain' ;
//     } else if (condition == 201) {
//       return 'thunderstorm with rain';
//     } else if (condition == 202) {
//       return 'thunderstorm with heavy rain';
//     } else if (condition == 210) {
//       return 'light thunderstorm';
//     } else if (condition == 211) {
//       return 'thunderstorm';
//     } else if (condition == 212) {
//       return 'heavy thunderstorm';
//     } else if (condition == 221) {
//       return 'ragged thunderstorm	';
//     } else if (condition == 30) {
//       return 'thunderstorm with light drizzle	';
//     } else if (condition == 231) {
//       return 'thunderstorm with drizzle';
//     } else if (condition == 232) {
//       return 'thunderstorm with heavy drizzle';
//     }
//     else{
//       return '';
//     }
//   }
//   String getMessage(int temp) {
//     if (temp > 25) {
//       return 'It\'s 🍦 time';
//     } else if (temp > 20) {
//       return 'Time for shorts and 👕';
//     } else if (temp < 10) {
//       return 'You\'ll need 🧣 and 🧤';
//     } else {
//       return 'Bring a 🧥 just in case';
//     }
//   }
// }
