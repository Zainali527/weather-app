// class Model {
//   String cod;
//   int message;
//   int cnt;
//   List<ListElement> list;
//   City city;
//
//   Model({
//     required this.cod,
//     required this.message,
//     required this.cnt,
//     required this.list,
//     required this.city,
//   });
// }
//
// class City {
//   int id;
//   String name;
//   Coord coord;
//   String country;
//   int population;
//   int timezone;
//   int sunrise;
//   int sunset;
//   City({
//     required this.id,
//     required this.name,
//     required this.coord,
//     required this.country,
//     required this.population,
//     required this.timezone,
//     required this.sunrise,
//     required this.sunset,
//   });
//
// }
//
// class Coord {
//   double lat;
//   double lon;
//
//   Coord({
//     required this.lat,
//     required this.lon,
//   });
//
// }
//
// class ListElement {
//   int? dt;
//   MainClass main;
//   List<Weather> weather;
//   Clouds? clouds;
//   Wind? wind;
//   int? visibility;
//   int? pop;
//   Sys? sys;
//   DateTime? dtTxt;
//
//   ListElement({
//      this.dt,
//     required this.main,
//     required this.weather,
//      this.clouds,
//      this.wind,
//      this.visibility,
//      this.pop,
//      this.sys,
//      this.dtTxt,
//   });
//
// }
//
// class Clouds {
//   int all;
//
//   Clouds({
//     required this.all,
//   });
//
// }
//
// class MainClass {
//   var temp;
//   var feelsLike;
//   var tempMin;
//   var tempMax;
//   var pressure;
//   var seaLevel;
//   var grndLevel;
//   var tempKf;
//   var hourlyTime;
//   var date;
//   var visibility;
//   var Id;
//   var City;
//   var Humidity;
//   var Windspeed;
//   var Visibility;
//   var Description;
//   var WeatherImage;
//   var todayDate;
//   MainClass({
//     this.temp,
//     required this.feelsLike,
//     required this.tempMin,
//     required this.tempMax,
//     this.pressure,
//     this.seaLevel,
//     this.grndLevel,
//     this.tempKf,
//     this.hourlyTime,
//     this.date,
//     this.visibility,
//     required this.Id,
//     required this.City,
//     required this.Humidity,
//     required this.Windspeed,
//     required this.Visibility,
//     this.Description,
//     this.WeatherImage,
//     this.todayDate,
//   });
//
// }
//
// class Sys {
//   Pod pod;
//
//   Sys({
//     required this.pod,
//   });
//
// }
//
// enum Pod {
//   D,
//   N
// }
//
// class Weather {
//   int id;
//   MainEnum? main;
//   Description? description;
//   String? icon;
//
//   Weather({
//     required this.id,
//      this.main,
//      this.description,
//     this.icon,
//   });
//
// }
//
// enum Description {
//   BROKEN_CLOUDS,
//   CLEAR_SKY,
//   FEW_CLOUDS,
//   OVERCAST_CLOUDS,
//   SCATTERED_CLOUDS
// }
//
// enum MainEnum {
//   CLEAR,
//   CLOUDS
// }
//
// class Wind {
//   double speed;
//   int deg;
//   double gust;
//
//   Wind({
//     required this.speed,
//     required this.deg,
//     required this.gust,
//   });
//
// }

class Welcome {
  Location? location;
  Current? current;
  Forecast? forecast;

  Welcome({
    this.location,
    this.current,
    this.forecast,
  });
}

class Current {
  String? lastUpdatedEpoch;
  String? lastUpdated;
  var tempC;
  double? tempF;
  int? isDay;
  List<Condition>? condition;
  double? windMph;
  double? windKph;
  var windDegree;
  WindDir? windDir;
  int? pressureMb;
  int? pressureIn;
  double? precipMm;
  double? precipIn;
  var humidity;
  int? cloud;
  var feelslikeC;
  double? feelslikeF;
  var visKm;
  int? visMiles;
  int? uv;
  int? gustMph;
  double? gustKph;
  String? date;

  Current({
    this.lastUpdatedEpoch,
    this.lastUpdated,
    this.tempC,
    this.tempF,
    this.isDay,
    this.condition,
    this.windMph,
    this.windKph,
    this.windDegree,
    this.windDir,
    this.pressureMb,
    this.pressureIn,
    this.precipMm,
    this.precipIn,
    this.humidity,
    this.cloud,
    this.feelslikeC,
    this.feelslikeF,
    this.visKm,
    this.visMiles,
    this.uv,
    this.gustMph,
    this.gustKph,
    this.date,
  });
}

class Condition {
  var text;
  var icon;
  int? code;

  Condition({
    this.text,
    this.icon,
    this.code,
  });
}

enum text {
  CLEAR,
  CLOUDY,
  FOG,
  LIGHT_DRIZZLE,
  LIGHT_RAIN_SHOWER,
  MIST,
  MODERATE_RAIN,
  OVERCAST,
  PARTLY_CLOUDY,
  PATCHY_LIGHT_DRIZZLE,
  PATCHY_RAIN_NEARBY,
  SUNNY
}

enum WindDir { E, ENE, ESE, NE, NNE, S, SE, SSE, SSW, SW, W, WSW }

class Forecast {
  List<Forecastday>? forecastday;

  Forecast({
    this.forecastday,
  });
}

class Forecastday {
  DateTime? date;
  int? dateEpoch;
  Day? day;
  Astro? astro;
  List<Hour>? hour;

  Forecastday({
    this.date,
    this.dateEpoch,
    this.day,
    this.astro,
    this.hour,
  });
}

class Astro {
  String? sunrise;
  String? sunset;
  String? moonrise;
  String? moonset;
  String? moonPhase;
  int? moonIllumination;
  int? isMoonUp;
  int? isSunUp;

  Astro({
    this.sunrise,
    this.sunset,
    this.moonrise,
    this.moonset,
    this.moonPhase,
    this.moonIllumination,
    this.isMoonUp,
    this.isSunUp,
  });
}

class Day {
  var maxtempC;
  double? maxtempF;
  var mintempC;
  double? mintempF;
  var avgtempC;
  double? avgtempF;
  double? maxwindMph;
  var maxwindKph;
  double? totalprecipMm;
  double? totalprecipIn;
  int? totalsnowCm;
  var avgvisKm;
  int? avgvisMiles;
  var avghumidity;
  int? dailyWillItRain;
  int? dailyChanceOfRain;
  int? dailyWillItSnow;
  int? dailyChanceOfSnow;
  var condition;
  int? uv;
  var day;
  var date_n_day;

  Day(
      {this.maxtempC,
      this.maxtempF,
      this.mintempC,
      this.mintempF,
      this.avgtempC,
      this.avgtempF,
      this.maxwindMph,
      this.maxwindKph,
      this.totalprecipMm,
      this.totalprecipIn,
      this.totalsnowCm,
      this.avgvisKm,
      this.avgvisMiles,
      this.avghumidity,
      this.dailyWillItRain,
      this.dailyChanceOfRain,
      this.dailyWillItSnow,
      this.dailyChanceOfSnow,
      this.condition,
      this.uv,
      this.day,
      this.date_n_day});
}

class Hour {
  int? timeEpoch;
  var time;
  var tempC;
  double? tempF;
  int? isDay;
  var condition;
  double? windMph;
  double? windKph;
  int? windDegree;
  WindDir? windDir;
  int? pressureMb;
  double? pressureIn;
  double? precipMm;
  double? precipIn;
  int? snowCm;
  int? humidity;
  int? cloud;
  double? feelslikeC;
  double? feelslikeF;
  double? windchillC;
  double? windchillF;
  double? heatindexC;
  double? heatindexF;
  double? dewpointC;
  double? dewpointF;
  int? willItRain;
  int? chanceOfRain;
  int? willItSnow;
  int? chanceOfSnow;
  double? visKm;
  int? visMiles;
  double? gustMph;
  double? gustKph;
  int? uv;

  Hour({
    this.timeEpoch,
    this.time,
    this.tempC,
    this.tempF,
    this.isDay,
    this.condition,
    this.windMph,
    this.windKph,
    this.windDegree,
    this.windDir,
    this.pressureMb,
    this.pressureIn,
    this.precipMm,
    this.precipIn,
    this.snowCm,
    this.humidity,
    this.cloud,
    this.feelslikeC,
    this.feelslikeF,
    this.windchillC,
    this.windchillF,
    this.heatindexC,
    this.heatindexF,
    this.dewpointC,
    this.dewpointF,
    this.willItRain,
    this.chanceOfRain,
    this.willItSnow,
    this.chanceOfSnow,
    this.visKm,
    this.visMiles,
    this.gustMph,
    this.gustKph,
    this.uv,
  });
}

class Location {
  String? name;
  String? region;
  String? country;
  double? lat;
  double? lon;
  String? tzId;
  int? localtimeEpoch;
  String? localtime;

  Location({
    this.name,
    this.region,
    this.country,
    this.lat,
    this.lon,
    this.tzId,
    this.localtimeEpoch,
    this.localtime,
  });
}
