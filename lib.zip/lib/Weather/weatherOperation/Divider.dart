import 'package:flutter/material.dart';

class Small_divider extends StatelessWidget {
  final Color color;

  Small_divider({required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 120,
      child: Divider(
        color: color,
        thickness: 1,
      ),
    );
  }
}
