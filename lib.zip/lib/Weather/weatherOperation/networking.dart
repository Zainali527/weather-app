import 'package:http/http.dart' as http;
import 'dart:convert';

class Network {
  final String URL;

  Network({required this.URL});

  Future GetApiData() async {
    String UrlString = (URL);
    var uri = Uri.parse(UrlString);
    var response = await http.get(uri);
    if (response.statusCode == 200) {
      String output = response.body;
      return jsonDecode(output);
    } else {
      int status = response.statusCode;
      print('Statuscode is = $status');
    }
  }
}
