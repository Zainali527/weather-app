import 'package:flutter/material.dart';

// const kdisplaycolor = Color.fromARGB(100,17,31,40);
// const khourlydisplycolor = Color.fromARGB(220, 17, 31, 40);
// olor.fromARGB(180,175,185,197)

const kMain_color = Color(0xff070827);
const kMain_color_Low_OP = Color.fromARGB(255, 35, 34, 75);
const kSecondary_color = Color(0xff2686e4);
const kSkyBlue_color = Color(0xff5bcffb);
const kSmall_text_light = TextStyle(color: Colors.white, fontFamily: 'Dosis',fontWeight: FontWeight.w700, fontSize: 16);
const kSmall_text_weight = TextStyle(color: Colors.white, fontFamily: 'Dosis', fontWeight: FontWeight.w700, fontSize: 16);
const kInactive_color = Color.fromARGB(255, 35, 34, 75);
const kActive_color = Color(0xff2686e4);


const k1 = Color(0xffddf2fe);
const k2 = Color.fromARGB(255, 35, 34, 75);
const k3 = Color(0xff070827);
const k4 = Color(0xff09090e);
const knew = Color.fromARGB(5, 66, 105, 162);