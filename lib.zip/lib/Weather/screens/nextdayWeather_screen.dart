import 'dart:ui';
import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import 'package:course/Weather/screens/WidgetConstant.dart';
import 'package:course/Weather/weatherOperation/Divider.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:course/Weather/weatherOperation/Model.dart';
import 'package:course/Weather/screens/HourlyDayforecast.dart';

class seven_Days_weather_forecast extends StatefulWidget {
  final int Index;

  seven_Days_weather_forecast({required this.Index});

  @override
  State<seven_Days_weather_forecast> createState() =>
      seven_Days_weather_forecastState();
}

List<Day> day_data = [];

class seven_Days_weather_forecastState
    extends State<seven_Days_weather_forecast> {
  bool exit = true;
  @override
  TodayHourState forday = TodayHourState();
  int currentIndex = 0;

  void gettest(dynamic data, int index) {
    currentIndex = index;
    print('currentIndex = $currentIndex');
    Day_Datafromhome(data, currentIndex);
    forday.Get_Day(data, currentIndex);
  }

  void Day_Datafromhome(dynamic data, int index) {
    day_data.clear();
    String dateString = data['forecast']['forecastday'][index]['date'];
    DateTime dateTime = DateFormat('yyyy-MM-dd').parse(dateString);
    String formattedDate = DateFormat('EEE, dd MMM, y').format(dateTime);
    day_data.add(Day(
      date_n_day: formattedDate,
      avgtempC: data['forecast']['forecastday'][index]['day']['avgtemp_c'],
      maxtempC: data['forecast']['forecastday'][index]['day']['maxtemp_c'],
      mintempC: data['forecast']['forecastday'][index]['day']['mintemp_c'],
      avgvisKm: data['forecast']['forecastday'][index]['day']['avgvis_km'],
      avghumidity: data['forecast']['forecastday'][index]['day']['avghumidity'],
      maxwindKph: data['forecast']['forecastday'][index]['day']['maxwind_kph'],
      condition: data['forecast']['forecastday'][index]['day']['condition']
          ['text'],
      dailyChanceOfRain: data['forecast']['forecastday'][index]['day']
          ['daily_chance_of_rain'],
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: k3,
      appBar: AppBar(
        leading: GestureDetector(
            onTap: () {
              Navigator.pop(context);
            },
            child: Icon(FontAwesomeIcons.angleDoubleLeft)),
        title: Text(
          'Weather',
          style: TextStyle(fontFamily: 'Dosis', fontWeight: FontWeight.bold),
        ),
        backgroundColor: kMain_color,
      ),
      body: Scrollbar(
        child: ListView(children: [
          Container(
            height: 470,
            decoration: BoxDecoration(
              color: kMain_color,
              //   borderRadius: BorderRadius.circular(20),
              //   gradient: LinearGradient(
              //     begin: Alignment.topLeft,
              //     end: Alignment.bottomRight,
              //     colors: [kMain_color,kSecondary_color,kMain_color],
              //   ),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Text(
                  '${day_data[0].date_n_day}',
                  style: kSmall_text_light,
                ),
                Image(image: AssetImage('images/day.png')),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(right: 17),
                      child: Text(
                        '${day_data[0].avgtempC.round()}°C',
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'Dosis',
                            fontSize: 68),
                      ),
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Row(
                          children: [
                            Text(
                              '${day_data[0].maxtempC.round()}°',
                              style: kSmall_text_light,
                            ),
                            Icon(
                              FontAwesomeIcons.arrowUp,
                              color: Colors.red,
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            Text(
                              '${day_data[0].mintempC.round()}°',
                              style: kSmall_text_light,
                            ),
                            Icon(
                              FontAwesomeIcons.arrowDown,
                              color: Colors.green,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
                Container(
                  width: 300,
                  // color: Colors.grey,
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Chances of rain',
                            style: kSmall_text_weight,
                          ),
                          Text(
                            '${day_data[0].dailyChanceOfRain == null ? '0' : '0'}%',
                            style: kSmall_text_light,
                          ),
                        ],
                      ),
                      Small_divider(
                        color: kSecondary_color,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Humidity',
                            style: kSmall_text_weight,
                          ),
                          Text(
                            '${day_data[0].avghumidity}%',
                            style: kSmall_text_light,
                          ),
                        ],
                      ),
                      Small_divider(
                        color: kSecondary_color,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Wind Speed',
                            style: kSmall_text_weight,
                          ),
                          Text(
                            '${day_data[0].maxwindKph.round()}Km/h',
                            style: kSmall_text_light,
                          ),
                        ],
                      ),
                      Small_divider(
                        color: kSecondary_color,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Visibility',
                            style: kSmall_text_weight,
                          ),
                          Text(
                            '${day_data[0].avgvisKm}Km',
                            style: kSmall_text_light,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 20, 10, 17),
            child: Text('24 hour forecast',
                style: TextStyle(
                    fontSize: 21,
                    fontFamily: 'Dosis',
                    fontWeight: FontWeight.w900)),
          ),
          Scrollbar(
            thickness: 5.0,
            child: Container(
              height: 400,
              child: TodayHour(),
            ),
          ),
        ]),
      ),
    );
  }
}
