import 'package:course/Weather/weatherOperation/networking.dart';
import 'package:course/Weather/weatherOperation/weather.dart';
import 'package:flutter/material.dart';
import '../weatherOperation/location.dart';
import 'home_screen.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

class LoadingScreen extends StatefulWidget {
  @override
  State<LoadingScreen> createState() => _LoadingScreenState();
}

class _LoadingScreenState extends State<LoadingScreen> {
  weathersetting get_data_and_push_Location_screen = weathersetting();

  @override
  // Future initState() async{
  //   super.initState();
  //   print('InitState');
  //   var alldata = await get_data_and_push_Location_screen.GetAlldata();
  //   // var weatherdata = await get_data_and_push_Location_screen.GetweatherData();
  //   // print('FORECAST DATA ===== $forecastdata');
  //   // print('WEATHER DATA ===== $weatherdata');
  //   // print('ALL WEATHER DATA ===== $alldata');
  //   Navigator.push(context,MaterialPageRoute(builder: (context)=> LocationScreen(alldata: alldata)));
  // }
  void test() async {
    var alldata = await get_data_and_push_Location_screen.GetAlldata(null);
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => LocationScreen(alldata: alldata)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: FutureBuilder(
            future: get_data_and_push_Location_screen.GetAlldata(null),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Container(
                  height: double.infinity,
                  decoration: BoxDecoration(
                      image: DecorationImage(
                    image: AssetImage('images/plane_sky.jpg'),
                    fit: BoxFit.cover,
                    colorFilter: ColorFilter.mode(
                        Colors.black.withOpacity(0.8), BlendMode.dstATop),
                  )),
                  child: SpinKitChasingDots(
                    color: Color.fromARGB(220, 17, 31, 40),
                    size: 50.0,
                  ),
                );
              } else if (snapshot.connectionState == ConnectionState.done ||
                  snapshot.connectionState == ConnectionState.active) {
                if (snapshot.hasError) {
                  return Text('Something went wrong');
                } else if (snapshot.hasData) {
                  print('Snapshot. data = ${snapshot.data}');
                  var Data = snapshot.data;
                  print(Data);
                  test();
                  return Container(
                    height: double.infinity,
                    decoration: BoxDecoration(
                        image: DecorationImage(
                      image: AssetImage('images/plane_sky.jpg'),
                      fit: BoxFit.cover,
                      colorFilter: ColorFilter.mode(
                          Colors.black.withOpacity(0.8), BlendMode.dstATop),
                    )),
                    child: SpinKitChasingDots(
                      color: Color.fromARGB(220, 17, 31, 40),
                      size: 50.0,
                    ),
                  );
                  // Navigator.push(context, MaterialPageRoute(
                  //    builder: (context) =>
                  //        LocationScreen(alldata: snapshot.data)));
                } else {
                  return Text('NO hash data');
                }
              } else {
                return Text('Issue here');
              }
            }),
      ),
    );
  }
}

// 5 days forecast after 3 hours
// https://web.postman.co/workspace/My-Workspace~2b4e93d2-642e-4e0a-8e4f-b92643373dd9/request/create?requestId=d0d9e381-51e6-4515-82f1-11678cf59118

// Container(
// height: double.infinity,
// decoration: BoxDecoration(
// image: DecorationImage(
// image: AssetImage('images/plane_sky.jpg'),
// fit: BoxFit.cover,
// colorFilter: ColorFilter.mode(Colors.black.withOpacity(0.8), BlendMode.dstATop),
// )
// ),
// child: SpinKitChasingDots(
// color: Color.fromARGB(220, 17, 31, 40),
// size: 50.0,
// ),
// ),
