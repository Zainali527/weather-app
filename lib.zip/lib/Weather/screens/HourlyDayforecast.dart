import 'package:course/Weather/screens/WidgetConstant.dart';
import 'package:course/Widgets/IndivuallWeatherWidget.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:course/Weather/weatherOperation/Model.dart';
import 'package:intl/intl.dart';

class TodayHour extends StatefulWidget {
  @override
  State<TodayHour> createState() => TodayHourState();
}

List<Hour> hourly_data = [];

Map<String, String> ImagesMap = {
  'Sunny': 'images/day.png',
  'Mist': 'images/mist.png',
  'Clear ': 'images/3333.png',
  'Clear': 'images/3333.png',
  'Partly cloudy': 'images/overcast_cloud.png',
  'Partly Cloudy ': 'images/overcast_cloud.png',
  'Overcast': 'images/overcast.png',
  'Patchy rain nearby': 'images/rain.png',
  'Cloudy ': 'images/clouds.png',
  'Light rain shower': 'images/rain.png',
  'Moderate rain': 'images/thunderstrom.png',
  'Patchy Light drizzle': 'images/drizzling.png',
  'Light drizzle': 'images/drizzling.png',
  'Fog': 'images/snow.png',
  'Thundery outbreaks in nearby': 'images/thunderstrom.png',
};

class TodayHourState extends State<TodayHour> {
  bool? exit = true;

  bool POP(exit) {
    print('Exit = $exit');
    return exit;
  }

  void Get_Day(dynamic data, int getday) {
    print('GETDAY =  $getday');
    Hourly_Datafromhome(data, getday);
  }

  final List<bool> click = List.generate(24, (index) => false);

  void Hourly_Datafromhome(dynamic data, int Selected_day) {
    hourly_data.clear();
    print('Selected day =  $Selected_day');
    for (int i = 0;
        i < (data['forecast']['forecastday'][0]['hour'].length);
        i++) {
      String getTime =
          data['forecast']['forecastday'][Selected_day]['hour'][i]['time'];
      DateTime dateTime = DateTime.parse(getTime);
      String timeString = DateFormat("hh:mm a").format(dateTime);
      hourly_data.add(Hour(
        time: timeString,
        tempC: data['forecast']['forecastday'][Selected_day]['hour'][i]
            ['temp_c'],
        condition: data['forecast']['forecastday'][Selected_day]['hour'][i]
            ['condition']['text'],
        feelslikeC: data['forecast']['forecastday'][Selected_day]['hour'][i]
            ['feelslike_c'],
        humidity: data['forecast']['forecastday'][Selected_day]['hour'][i]
            ['humidity'],
        windKph: data['forecast']['forecastday'][Selected_day]['hour'][i]
            ['wind_kph'],
        chanceOfRain: data['forecast']['forecastday'][Selected_day]['hour'][i]
            ['chance_of_rain'],
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 100,
      child: ListView.builder(
          itemCount: 24,
          shrinkWrap: true,
          scrollDirection: Axis.vertical,
          itemBuilder: (context, int index) {
            return GestureDetector(
              onTap: () {
                setState(() {
                  if (click[index] == false) {
                    click[index] = true;
                  } else {
                    click[index] = false;
                  }
                });
              },
              child: click[index] == true
                  ? hourlDetails(
                      getindex: index,
                      gettime: hourly_data[index].time,
                    )
                  : ListTile(
                      leading: Text(
                        '${hourly_data[index].time}',
                        style: TextStyle(
                            fontSize: 12,
                            fontFamily: 'Dosis',
                            fontWeight: FontWeight.bold),
                      ),
                      title: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                  vertical: 0, horizontal: 14),
                              child: Text(
                                '${hourly_data[index].tempC.round()}°C',
                                style: kSmall_text_weight,
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                  vertical: 0, horizontal: 10),
                              child: SizedBox(
                                  width: 26,
                                  height: 26,
                                  child: Image(
                                      image: AssetImage(
                                          '${ImagesMap['${hourly_data[index].condition}']}'))),
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                  vertical: 0, horizontal: 10),
                              child: Text(
                                '${hourly_data[index].condition}',
                                style: kSmall_text_light,
                              ),
                            ),
                          ]),
                      trailing: Icon(FontAwesomeIcons.angleDown),
                    ),
            );
          }),
    );
  }
}

class hourlDetails extends StatelessWidget {
  final int getindex;
  final String gettime;

  hourlDetails({required this.getindex, required this.gettime});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ListTile(
          leading: Text(
            '$gettime',
            style: TextStyle(
                fontSize: 12,
                color: Colors.white,
                fontFamily: 'Dosis',
                fontWeight: FontWeight.bold),
          ),
          title: Row(mainAxisAlignment: MainAxisAlignment.start, children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 0, horizontal: 14),
              child: Text(
                '${hourly_data[getindex].tempC.round()}°C',
                style: kSmall_text_weight,
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 0, horizontal: 10),
              child: SizedBox(
                  width: 26,
                  height: 26,
                  child: Image(
                      image: AssetImage(
                          '${ImagesMap['${hourly_data[getindex].condition}']}'))),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 0, horizontal: 10),
              child: Text(
                hourly_data[getindex]
                        .condition
                        .contains('Thundery outbreaks in nearby')
                    ? 'Thunder nearby'
                    : '${hourly_data[getindex].condition}',
                style: kSmall_text_light,
              ),
            ),
          ]),
          trailing: Icon(FontAwesomeIcons.anglesUp),
        ),
        Container(
          height: 140,
          width: 340,
          decoration: BoxDecoration(
            // color: knew,
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(0),
                topRight: Radius.circular(0),
                bottomLeft: Radius.circular(17),
                bottomRight: Radius.circular(17)),
            boxShadow: [
              BoxShadow(
                color: kSecondary_color.withOpacity(0.4),
                spreadRadius: 1.0,
                blurRadius: 1.0,
                offset: Offset(1.0, 2.0),
              )
            ],
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [k2, k2, k3, k3, k4],
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(15.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Feels like',
                      style: kSmall_text_weight,
                    ),
                    Text(
                      '${hourly_data[getindex].feelslikeC}°C',
                      style: kSmall_text_light,
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Humidity',
                      style: kSmall_text_weight,
                    ),
                    Text(
                      '${hourly_data[getindex].humidity}%',
                      style: kSmall_text_light,
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Wind Speed',
                      style: kSmall_text_weight,
                    ),
                    Text(
                      '${hourly_data[getindex].windKph} Km/h',
                      style: kSmall_text_light,
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Chance of rain',
                      style: kSmall_text_weight,
                    ),
                    Text(
                      '${hourly_data[getindex].chanceOfRain}%',
                      style: kSmall_text_light,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
