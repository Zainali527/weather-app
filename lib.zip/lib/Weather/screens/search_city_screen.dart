import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:anim_search_bar/anim_search_bar.dart';
import 'home_screen.dart';

class SearchCity extends StatefulWidget {
  @override
  _SearchCityState createState() => _SearchCityState();
}

class _SearchCityState extends State<SearchCity> {
  String CityName = '';
  List<String> suggestions = [
    "Multan",
    "Lahore",
    "Brisbane",
    "karachi",
    "London",
    "Islamabad",
    "Mumbai",
    "New york",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade900,
      body: Container(
        constraints: BoxConstraints.expand(),
        child: SafeArea(
          child: Column(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.all(17.0),
                child: SizedBox(
                  height: 50,
                  width: 400,
                  child: TextField(
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.black,
                      // contentPadding: EdgeInsets.fromLTRB(left, top, right, bottom),
                      // icon: Icon(FontAwesomeIcons.search, color: Colors.black,),
                      prefixIcon: Icon(
                        FontAwesomeIcons.search,
                        size: 17,
                      ),
                      hintText: '',
                      floatingLabelBehavior: FloatingLabelBehavior.never,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(40.0),
                        borderSide: BorderSide.none,
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(40.0),
                        borderSide: BorderSide(color: Colors.grey),
                      ),
                      label: Text(
                        'search',
                        style: TextStyle(fontSize: 19, color: Colors.grey),
                      ),
                      suffixIcon: InkWell(
                          onTap: () {
                            Navigator.pop(context, CityName);
                          },
                          child: Icon(
                            FontAwesomeIcons.paperPlane,
                            size: 17,
                          )),
                    ),
                    onChanged: (value) {
                      CityName = value;
                      print('City name = $CityName');
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
