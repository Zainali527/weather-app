import 'dart:async';
import 'package:course/Weather/weatherOperation/location.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:course/Weather/screens/WidgetConstant.dart';
import 'package:course/Weather/weatherOperation/weather.dart';
import 'package:course/Weather/weatherOperation/Divider.dart';
import 'package:course/Weather/screens/search_city_screen.dart';
import 'package:course/Weather/weatherOperation/Model.dart';
import 'package:intl/intl.dart';
import 'package:course/Weather/screens/nextdayWeather_screen.dart';
import 'package:course/Weather/screens/HourlyDayforecast.dart';
import 'package:course/Weather/screens/nextdayWeather_screen.dart';
import 'package:flutter/services.dart';

weathersetting WeatherSetting = weathersetting();

class LocationScreen extends StatefulWidget {
  final alldata;

  LocationScreen({required this.alldata});

  @override
  _LocationScreenState createState() => _LocationScreenState();
}

// String Check = 'MIST';
class _LocationScreenState extends State<LocationScreen> {
  String? newUrl;
  TodayHourState hourWeather = TodayHourState();
  seven_Days_weather_forecastState day_data =
      seven_Days_weather_forecastState();
  List<Current> current_weather = [];
  List<Condition> current_condition = [];
  List<Location> weather_location = [];
  List<Day> current_day = [];

  // day_data.Day_Datafromhome(widget.alldata);
  void initState() {
    Updateui(widget.alldata);
    hourWeather.Get_Day(widget.alldata, 0);
  }

  void test(int getindex) {
    print('Index in test is  = $getindex');
    day_data.gettest(widget.alldata, getindex);
    // day_data.Day_Datafromhome(widget.alldata, getindex);
  }

  // String displayImage(){
  //   dynamic WeatherData = widget.alldata;
  //   checktext = WeatherData['current']['condition']['text'];
  //   if (check.MIST == checktext){
  //     return 'images/clouds.png';
  //   }else if (Check == checktext){
  //      return 'images/sun.png';
  //   }else{
  //     return 'helllo';
  //   }
  // }

  Map<String, String> ImagesMap = {
    'Sunny': 'images/day.png',
    'Mist': 'images/mist.png',
    'Clear': 'images/3333.png',
    'Clear ': 'images/3333.png',
    'Partly cloudy': 'images/overcast_cloud.png',
    'Partly Cloudy ': 'images/overcast_cloud.png',
    'Overcast': 'images/overcast.png',
    'Overcast ': 'images/overcast.png',
    'Patchy rain nearby': 'images/rain.png',
    'Cloudy': 'images/clouds.png',
    'Light rain shower': 'images/rain.png',
    'Moderate rain': 'images/thunderstrom.png',
    'Patchy Light drizzle': 'images/drizzling.png',
    'Light drizzle': 'images/drizzling.png',
    'Fog': 'images/snow.png',
  };

  void Updateui(dynamic WeatherData) {
    final DateTime dateTime = DateTime.now();
    final DateFormat timeFormatter = DateFormat("h:mm a");
    final DateFormat dateFormat = DateFormat("EEE, MMM d 'yy");
    String time = timeFormatter.format(dateTime);
    String MainDate = dateFormat.format(dateTime);
    String seven_days;

    current_weather = [
      Current(
        tempC: WeatherData['current']['temp_c'],
        windKph: WeatherData['current']['wind_kph'],
        humidity: WeatherData['current']['humidity'],
        feelslikeC: WeatherData['current']['feelslike_c'],
        visKm: WeatherData['current']['vis_km'],
        date: MainDate,
      )
    ];
    current_condition = [
      Condition(
        text: WeatherData['current']['condition']['text'],
        icon: WeatherData['current']['condition']['icon'],
      )
    ];
    weather_location = [
      Location(
        name: WeatherData['location']['name'],
        country: WeatherData['location']['country'],
      )
    ];
    current_day = [];
    for (int i = 0; i < WeatherData['forecast']['forecastday'].length; i++) {
      int days = WeatherData['forecast']['forecastday'][i]['date_epoch'];
      DateTime date = DateTime.fromMillisecondsSinceEpoch(days * 1000);
      seven_days = DateFormat('EEEE').format(date).substring(0, 3);
      current_day.add(Day(
        maxtempC: WeatherData['forecast']['forecastday'][i]['day']['maxtemp_c'],
        mintempC: WeatherData['forecast']['forecastday'][i]['day']['mintemp_c'],
        condition: WeatherData['forecast']['forecastday'][i]['day']['condition']
            ['text'],
        day: seven_days,
      ));
      print('check current_DAy_condition ${current_day[i].condition}');
      print(
          'check current_Day_condition ${ImagesMap['${current_day[i].condition}']}');
    }
    print('check current_condition ${current_condition[0].text}');
    print(
        'check current_condition ${ImagesMap['${current_condition[0].text}']}');
    setState(() {});
    // print('check current_DAy_condition ${current_day[0].condition}');
    // print('check current_Day_condition ${ImagesMap['${current_day[0].condition}']}');
  }

  // }
  @override
  Widget build(BuildContext context) {
    Color clo = kInactive_color;
    return Scaffold(
        backgroundColor: kMain_color,
        body: SafeArea(
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                colors: [k1, k2, k3, k4],
              ),
            ),
            child: Scrollbar(
              child: ListView(
                children: [
                  Container(
                    height: 560,
                    // color: Colors.grey,
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 10),
                              child: Icon(
                                FontAwesomeIcons.navicon,
                                size: 27,
                                color: Colors.white,
                              ),
                            ),
                            Column(
                              children: [
                                Text(
                                  "${weather_location[0].name}",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 20,
                                    fontFamily: 'Dosis',
                                  ),
                                ),
                                Text(
                                  "${weather_location[0].country}",
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'Dosis',
                                      fontSize: 20),
                                ),
                                Text(
                                  '${current_weather[0].date}',
                                  style: TextStyle(
                                      fontSize: 17,
                                      fontFamily: 'Dosis',
                                      fontWeight: FontWeight.bold),
                                )
                              ],
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 10),
                              child: InkWell(
                                onTap: () async {
                                  var recievedCity = await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => SearchCity()));
                                  print('CiTTTTTTYYYYYYYYY  = $recievedCity');
                                  if (recievedCity != null) {
                                    var weatherData = await weathersetting()
                                        .GetAlldata(recievedCity);
                                    print(' here $weatherData');
                                    if (weatherData != null) {
                                      Updateui(weatherData);
                                    }
                                  }
                                },
                                child: Icon(
                                  FontAwesomeIcons.locationArrow,
                                  size: 27,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ],
                        ),
                        Column(
                          children: [
                            Image(
                              image: AssetImage(
                                  '${ImagesMap['${current_condition[0].text}']}'),
                              height: 190,
                            ),
                            Text(
                              "${current_condition[0].text}",
                              style: kSmall_text_light,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(right: 17),
                                  child: Text(
                                    '${current_weather[0].tempC.round()}°C',
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w600,
                                        fontFamily: 'Dosis',
                                        fontSize: 68),
                                  ),
                                ),
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          '${current_day[0].maxtempC.round()}°',
                                          style: kSmall_text_light,
                                        ),
                                        Icon(
                                          FontAwesomeIcons.arrowUp,
                                          color: Colors.red,
                                        ),
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        Text(
                                          '${current_day[0].mintempC.round()}°',
                                          style: kSmall_text_light,
                                        ),
                                        Icon(
                                          FontAwesomeIcons.arrowDown,
                                          color: Colors.green,
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            Container(
                              width: 300,
                              // height: double.infinity,
                              // color: Colors.grey,
                              child: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        'Feels like',
                                        style: kSmall_text_weight,
                                      ),
                                      Text(
                                        '${current_weather[0].feelslikeC.round()}°C',
                                        style: kSmall_text_light,
                                      ),
                                    ],
                                  ),
                                  Small_divider(
                                    color: kSecondary_color,
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        'Humidity',
                                        style: kSmall_text_weight,
                                      ),
                                      Text(
                                        '${current_weather[0].humidity}%',
                                        style: kSmall_text_light,
                                      ),
                                    ],
                                  ),
                                  Small_divider(
                                    color: kSecondary_color,
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        'Wind Speed',
                                        style: kSmall_text_weight,
                                      ),
                                      Text(
                                        '${current_weather[0].windKph} Km/h',
                                        style: kSmall_text_light,
                                      ),
                                    ],
                                  ),
                                  Small_divider(
                                    color: kSecondary_color,
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        'Visibility',
                                        style: kSmall_text_weight,
                                      ),
                                      Text(
                                        '${current_weather[0].visKm}Km',
                                        style: kSmall_text_light,
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text('Next 7 Days',
                        style: TextStyle(
                            fontSize: 21,
                            fontFamily: 'Dosis',
                            fontWeight: FontWeight.w900)),
                  ),
                  SizedBox(
                    height: 147,
                    child: ListView.builder(
                        itemCount: 7,
                        shrinkWrap: true,
                        scrollDirection: Axis.horizontal,
                        itemBuilder: (BuildContext context, index) {
                          return Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: GestureDetector(
                              onTap: () {
                                setState(() {
                                  test(index);
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              seven_Days_weather_forecast(
                                                Index: index,
                                              )));
                                });
                              },
                              child: Container(
                                height: 110,
                                width: 87,
                                decoration: BoxDecoration(
                                  color: kMain_color,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(30.0)),
                                  border: Border.all(
                                      color: kMain_color,
                                      width: 1,
                                      style: BorderStyle.solid),
                                  boxShadow: [
                                    BoxShadow(
                                      color: kSecondary_color.withOpacity(0.5),
                                      spreadRadius: 1.1,
                                      blurRadius: 1.0,
                                      offset: Offset(1.0,
                                          2.0), // Shadow below the container
                                    ),
                                  ],
                                ),
                                child: Column(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceEvenly,
                                  children: [
                                    Padding(
                                      padding:
                                          const EdgeInsets.fromLTRB(2, 8, 4, 0),
                                      child: Text('${current_day[index].day}',
                                          style: kSmall_text_light),
                                    ),
                                    Image(
                                      image: AssetImage(
                                          '${ImagesMap['${current_day[index].condition}']}'),
                                      height: 40,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Text(
                                          '${current_day[index].maxtempC.round()}°/',
                                          style: TextStyle(
                                              fontSize: 18,
                                              color: Colors.white,
                                              fontFamily: 'Dosis',
                                              fontWeight: FontWeight.bold),
                                        ),
                                        Text(
                                          '${current_day[index].mintempC.round()}°',
                                          style: TextStyle(
                                              fontSize: 18,
                                              color: Colors.white,
                                              fontFamily: 'Dosis',
                                              fontWeight: FontWeight.bold),
                                        )
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        }),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(10, 19, 10, 17),
                    child: Text('24 hour forecast',
                        style: TextStyle(
                            fontSize: 21,
                            fontFamily: 'Dosis',
                            fontWeight: FontWeight.w900)),
                  ),
                  Scrollbar(
                    thickness: 5.0,
                    child: Container(
                      height: 400,
                      child: TodayHour(),
                    ),
                  )
                ],
              ),
            ),
          ),
        ));
  }
}
