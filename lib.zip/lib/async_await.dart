import 'dart:io';
void performance () async{
  task1();
  String task_2_output = await task2();
  task3(task_2_output);
}
void task1 (){
  print('Print task 1');
}

Future<String> task2 () async{
  String result = 'NULL';
  Duration fiveSec = Duration(seconds: 5);
  await Future.delayed(fiveSec, (){
    result = 'TASK_2';
    print('Print task 2');
    //Now we make this async by using callback function
    // now first display step1 and step3 and after 5 sec of delay display step2
    //but what if step3 display data which comes from step2?
  });
  return result;
  // sleep(threeSec);
  // print('Print task 2');
  // here we make an artificial delay for some cases the data like image etc might take time to display 
  // for this we use asyncronaeus (async) to move to the next step and don't waste time on it
  // instead of sync which will wait to complete the step and then move towards the next step

}
void task3 (String result){
  print('Print task 3 and data comes from step 2 is $result');
}