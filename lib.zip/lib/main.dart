// // import 'package:flutter/material.dart';
// // void main(){
// //   runApp(app());
// // }
// // class app extends StatelessWidget{
// //   @override
// //   Widget build(BuildContext context){
// //     return MaterialApp(
// //           home: Scaffold(
// //             backgroundColor: Colors.black26,
// //             body: Center(
// //               child: Column(
// //                 mainAxisAlignment: MainAxisAlignment.center,
// //                 children: [
// //                   CircleAvatar(
// //                     backgroundImage: AssetImage("images/cat.jpeg"),
// //                     radius: 100,
// //                   ),
// //                   Text("This is Zain",
// //                     style: TextStyle(
// //                       color: Colors.white,
// //                       fontFamily: 'Pacifico',
// //                       fontWeight: FontWeight.bold,
// //                       fontSize: 40,
// //                     ),
// //                   ),
// //
// //                     Text("Flutter Developer",
// //                       style: TextStyle(
// //                         color: Colors.white,
// //                         fontFamily: "SourceSans3",
// //                         fontWeight: FontWeight.bold,
// //                         fontSize: 20,
// //                       ),
// //                     ),
// //
// //                   SizedBox(
// //                     width: 180,
// //                     child: Divider(
// //                       height: 10,
// //                       color: Colors.white,
// //                     ),
// //                   ),
// //                   Container(
// //                     // height: 55,
// //                     // width: 300,
// //                     margin: EdgeInsets.symmetric(vertical: 10, horizontal: 25),
// //                     // padding: EdgeInsets.all((3)),
// //                     color: Colors.white,
// //                     child: ListTile(
// //                       leading: Icon(
// //                         Icons.phone,
// //                         size: 20,
// //                       ),
// //                       title: Text(
// //                         "+44 234 656 867",
// //                         style: TextStyle(
// //                           fontSize: 20,
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                   // SizedBox(
// //                   //   height: 10,
// //                   // ),
// //
// //                   Container(
// //                     // height: 55,
// //                     // width: 300,
// //                     margin: EdgeInsets.symmetric(vertical: 15, horizontal: 25),
// //                     // padding: EdgeInsets.all((7)),
// //                     color: Colors.white,
// //                     child: ListTile(
// //                       leading: Icon(
// //                         Icons.phone,
// //                         size: 20,
// //                       ),
// //                       title: Text(
// //                         "Helohfs@gmail.com",
// //                         style: TextStyle(
// //                           fontSize: 20,
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ],
// //               ),
// //             ),
// //           ),
// //         );
// //   }
// // }
//
//
//
//
//
//
//
// //---------------Dice project---------//
// import 'dart:math';
// import 'package:flutter/material.dart';
// void main(){
//   runApp(dicepage());
// }
// class dicepage extends StatefulWidget{
//   _dicepage createState()=> _dicepage();
// }
// class _dicepage extends State<dicepage>{
//   int leftdicenumber = 1;
//   int rightdicenumber = 1;
//   @override
//   Widget build(BuildContext context){
//     void number (){
//       leftdicenumber = Random().nextInt(6)+1;
//       rightdicenumber = Random().nextInt(6)+1;
//     }
//     return MaterialApp(
//       home: Scaffold(
//         backgroundColor: Colors.red,
//         appBar: AppBar(
//           title: Text("Dice App",style: TextStyle(
//             color: Colors.white,
//             ),
//           ),
//           backgroundColor: Colors.red,
//         ),
//         body: Center(
//           child: Row(
//             children: [
//               Expanded(
//                 child: TextButton(
//                   onPressed: (){
//                     setState(() {
//                       number();
//                     });
//                   },
//                   child: Image.asset("images/dice$leftdicenumber.png"),
//                 ),
//               ),
//               Expanded(
//                 child: TextButton(
//                   onPressed: (){
//                     setState(() {
//                       number();
//                     });
//                   },
//                     child: Image.asset("images/dice$rightdicenumber.png"),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }

//-----------Challenge-----------//
// import 'dart:math';
// import 'package:flutter/material.dart';
// void main (){
//   runApp(challenge());
// }
// class challenge extends StatefulWidget{
//   _challenge createState()=> _challenge();
// }
// class _challenge extends State<challenge>{
//   int number = 1;
//   @override
//   Widget build(BuildContext context){
//     return MaterialApp(
//       home: Scaffold(
//         backgroundColor: Colors.lightBlueAccent,
//         appBar: AppBar(
//           title: Text("Challenge"),
//           backgroundColor: Colors.lightBlueAccent.shade700,
//         ),
//         body: Center(
//             child: TextButton(
//               onPressed: (){
//                 setState(() {
//                   number=Random().nextInt(5)+1;
//                 });
//               },
//               child: Image.asset("images/ball$number.png"),
//             )
//         ),
//       ),
//     );
//   }
// }



//----------Xylophone--------//




//---------------Xylophone---------
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:english_words/english_words.dart';
// import 'package:audioplayers/audioplayers.dart';
// import 'package:flutter/painting.dart';
// import 'package:flutter/widgets.dart';
// void main (){
//   runApp(xylophone());
// }
// class xylophone extends StatefulWidget{
//   State<xylophone> createState()=> _xylophone();
// }
// class _xylophone extends State<xylophone>{
//   void playsound(int soundNumber){
//     final players = AudioPlayer();
//     players.play(AssetSource('note$soundNumber.wav'));
//   }
//   Expanded color (int sound, Color colorname){
//     return Expanded(
//       child: InkWell(
//         onTap: (){
//           playsound(sound);
//         },
//         child: Container(
//           height: 50,
//           width: double.infinity,
//           color: colorname,
//         ),
//       ),
//     );
//   }
//   @override
//   Widget build(BuildContext context){
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       home: Scaffold(
//         backgroundColor: Colors.black,
//         body: SafeArea(
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.stretch,
//               children: [
//                 color(1, Colors.yellow),
//                 color(2, Colors.red),
//                 color(3, Colors.pinkAccent.shade100),
//                 color(4, Colors.green),
//                 color(5, Colors.blue),
//                 color(6, Colors.orangeAccent),
//                 color(7, Colors.purpleAccent),
//               ],
//             ),
//         ),
//       ),
//     );
//   }
// }






//-------------Quizzler-------------



//-------------Quizler-------------------//
// import 'package:flutter/material.dart';
// import 'question_brain.dart';
// import 'package:rflutter_alert/rflutter_alert.dart';
// void main(){
//   runApp(MaterialApp(
//     home: quizzler(),
//     debugShowCheckedModeBanner: false,
//   ));
// }
// class quizzler extends StatefulWidget {
//   const quizzler({super.key});
//   @override
//   State<quizzler> createState() => _quizzlerState();
// }
// class _quizzlerState extends State<quizzler> {
//   @override
//
//
//
//
//   int count=0;
//   int right=0;
//   List<Icon> result =[];
//   void check_answer(bool useranswer){
//     bool correct_ans= brain.Q_ans() ;
//     if(useranswer == correct_ans  ){
//       right++;
//       result.add(Icon(Icons.check, color: Colors.green,),);
//     }
//     else{
//       result.add(Icon(Icons.close, color: Colors.red,),);
//     }
//     setState(() {
//       brain.change_number();
//     });
//   }
//   QuestionBrain brain = QuestionBrain();
//
//   Widget build(BuildContext context) {
//     showAlert(){
//       Alert(
//         context: context,
//         title: 'Finish',
//         desc: '$right correct answers out of $count',
//       ).show();
//     }
//     Gameover(){
//       if (count == brain.return_length()){
//         print('Length got end');
//         showAlert();
//         result.clear();
//         count= 0;
//         right =0;
//         print('Count in gameover is $count');
//       }
//     }
//
//
//     return Scaffold(
//         backgroundColor: Colors.black54,
//         appBar: AppBar(title: Text('Quizzler app', style: TextStyle(color: Colors.white, fontSize: 30),),backgroundColor: Colors.grey.shade900,),
//         body: Column(
//           children: [
//               Expanded(
//                 child: Container(
//                   height: 200,
//                   width: double.infinity,
//                   color: Colors.black,
//                   padding: EdgeInsets.all(10),
//                   child: Center(
//                     child: Text(brain.Q_text() ,style: TextStyle(
//                       color: Colors.white,
//                       fontWeight: FontWeight.w400,
//                       fontSize: 26,
//                     ),),
//                   ),
//                 ),
//               ),
//             Container(
//               width: 350,
//               height: 80,
//               color: Colors.green,
//               margin: EdgeInsets.fromLTRB(10, 20, 10, 10),
//               child: TextButton(
//                   onPressed: (){
//                     count++;
//                     if(count <= brain.return_length()){
//                       check_answer(true);
//                     }
//                     Gameover();
//                   },
//                   child: Text('True', style: TextStyle(fontSize: 25, color: Colors.white),),
//               ),
//             ),
//             Container(
//               width: 350,
//               height: 80,
//               color: Colors.red,
//               margin: EdgeInsets.fromLTRB(10, 10, 10, 30),
//               child: TextButton(
//                 onPressed: (){
//                   count++;
//                   if(count <= brain.return_length()){
//                     check_answer(false);
//                   }
//                   Gameover();
//                 },
//                   child: Text('False', style: TextStyle(fontSize: 25, color: Colors.white),),
//               ),
//             ),
//             Row(
//              children: result,
//             )
//           ],
//         ),
//     );
//   }
// }





//----------Boss level challange 2---------//



//-----------Boos Level challange-------//
// import 'package:course/story_c.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/rendering.dart';
// import 'package:course/story_brain_c.dart';
// import 'package:flutter/widgets.dart';
//
// //TODO: Step 15 - Run the app and see if you can see the screen update with the first story. Delete this TODO if it looks as you expected.
//
// void main() => runApp(Destini());
//
// class Destini extends StatelessWidget {
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       theme: ThemeData.dark(),
//       debugShowCheckedModeBanner: false,
//       home: StoryPage(),
//     );
//   }
// }
//
// //TODO: Step 9 - Create a new storyBrain object from the StoryBrain class.
//
// class StoryPage extends StatefulWidget {
//   _StoryPageState createState() => _StoryPageState();
// }
//
// class _StoryPageState extends State<StoryPage> {
//   Story_brain_c brain = Story_brain_c();
//   int index=0;
//   int cindex=0;
//   bool isVisible = true;
// //---------------Visible ------------
//   void visible(){
//     if(isVisible == true){
//       isVisible = false;
//     }
//     else
//     {
//       isVisible = true;
//     }
//   }
//   //----------Restart---------
//   void restart(){
//     if (cindex==5){
//       cindex=0;
//       visible();
//       print('Restart at 5  is $cindex');
//     }
//     else if (cindex==4){
//       cindex=0;
//       visible();
//       print('Restart at 4  is $cindex');
//     }
//     if (cindex==3){
//       cindex=0;
//       visible();
//       print('Restart at 3  is $cindex');
//     }
//   }
//   //-------------choice 1--------------
// void choice1 () {
//   if (cindex == 5 || cindex == 4 || cindex == 3) {
//     restart();
//   }
//   else if (cindex == 0) {
//     cindex += 2;
//     print('C_index in choice1 is $cindex');
//   }
//   else if (cindex == 1) {
//     cindex += 1;
//     print('C_index in choice1 is $cindex');
//   }
//   else if (cindex == 2) {
//     cindex += 3;
//     visible();
//   }
// }
// // -------------------choice 2-------------
//   void choice2 (){
//     if(cindex==5 || cindex==4 || cindex==3){
//       restart();
//     }
//   if(cindex==0){
//     cindex+= 1;
//   }
//   else if (cindex==2){
//     cindex +=2;
//     visible();
//   }
//   else if(cindex==1){
//     cindex+=2;
//     visible();
//     }
//   }
//
//
//
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: SafeArea(
//         child: Container(
//           padding: EdgeInsets.symmetric(vertical: 20, horizontal: 20),
//           decoration: BoxDecoration(
//             image: DecorationImage(
//               image: AssetImage('images/background.png'),
//               fit: BoxFit.cover,
//             )
//           ),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.stretch,
//             children: <Widget>[
//               Expanded(
//                 flex: 12,
//                 child: Center(
//                   child: Text(brain.text(cindex)
//                     ,style: TextStyle(
//                       fontSize: 25.0,
//                     ),
//                   ),
//                 ),
//               ),
//               Expanded(
//                 flex: 2,
//                 child: Container(
//                   decoration: BoxDecoration(
//                     borderRadius: BorderRadius.circular(25),
//                     color: Colors.red,
//                   ),
//                   child: TextButton(
//                     onPressed: () {
//                       setState(() {
//                         // brain.index_number();
//                         choice1();
//                       });
//                       },
//                     child: Text(
//                       brain.ans_choice1(),
//                       style: TextStyle(
//                         fontSize: 20.0,
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//               SizedBox(
//                 height: 20.0,
//               ),
//               Visibility(
//                 visible: isVisible,
//                 child: Expanded(
//                   flex: 2,
//                   //TODO: Step 26 - Use a Flutter Visibility Widget to wrap this FlatButton.
//                   //TODO: Step 28 - Set the "visible" property of the Visibility Widget to equal the output from the buttonShouldBeVisible() method in the storyBrain.
//                   child: Container(
//                     decoration: BoxDecoration(
//                       borderRadius: BorderRadius.circular(25),
//                       color: Colors.blue.shade800,
//                     ),
//                     child: TextButton(
//                       onPressed: () {
//                         setState(() {
//                           // brain.index_number();
//                           choice2();
//                         });
//                         },
//                       // color: Colors.blue,
//                       child: Text(
//                         //TODO: Step 14 - Use the storyBrain to get the text for choice 2.
//                         brain.ans_choice2(),
//                         style: TextStyle(
//                           fontSize: 20.0,
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
//
// //TODO: Step 24 - Run the app and try to figure out what code you need to add to this file to make the story change when you press on the choice buttons.
//
// //TODO: Step 29 - Run the app and test it against the Story Outline to make sure you've completed all the steps. The code for the completed app can be found here: https://github.com/londonappbrewery/destini-challenge-completed/






//--------BMI Calculator-----------
// import 'package:flutter/material.dart';
// import 'BMI_screens/input_page.dart';
// void main() => runApp(BMICalculator());
//
// class BMICalculator extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       theme: ThemeData.dark().copyWith(
//         primaryColor: Color(0xFF0A0E21),
//         scaffoldBackgroundColor: Color(0xFF0A0E21),),
//       home: InputPage(),
//     );
//   }
// }






//__________________Weather App--------//


import 'package:flutter/material.dart';
import 'Weather/screens/Loading_screen.dart';
import 'async_await.dart';
void main(){
  runApp(MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: LoadingScreen(),
    );
  }
}
//
// class temporary extends StatefulWidget {
//   @override
//   State<temporary> createState() => _StateTemporary();
// }
//
// class _StateTemporary extends State<temporary> {
//   @override
//   Widget build(BuildContext context) {
//     return FutureBuilder(future: _buildContext(context),
//         builder: (context, snapshot){
//           if(snapshot.hasData){
//             return snapshot.data!;
//           } else if (snapshot.hasError){
//             return Material(child: Center(child: Text('Connection error')));
//           }
//           return LoadingScreen();
//         }
//     );
//   }
//
//   Future<Widget> _buildContext(BuildContext context) async {
//     print('test');
//       weathersetting get_data_and_push_Location_screen = weathersetting();
//       print('test1');
//       var alldata = await get_data_and_push_Location_screen.GetAlldata();
//       print('fetched: ${alldata}');
//       return LocationScreen(alldata: alldata);
//   }
// }
//


