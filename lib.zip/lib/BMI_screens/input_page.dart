import 'package:course/BMI_components/BMI_brain.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../BMI_components/Layout_container.dart';
import '../BMI_components/Container_content.dart';
import '../BMI_components/Const_varibles.dart';
import '../BMI_components/Plus_minus_Icon.dart';
import 'Result.dart';
import '../BMI_components/BottomButton.dart';
import '../BMI_components/BMI_brain.dart';

enum gender {male, female, none}
int height = 180;
int weight = 60;
int age = 20;
class InputPage extends StatefulWidget {
  const InputPage({super.key});
  @override
  State<InputPage> createState() => _InputPageState();
}
class _InputPageState extends State<InputPage> {
  gender selectedGender = gender.none;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('BMI Calculator'),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          //-----------ROW
          Expanded(
            child: Row(
              children: [
                Expanded(
                  child: LayoutContainer(
                      onpress: (){
                        setState(() {
                          selectedGender = gender.male;
                        });
                      },
                      colour: selectedGender == gender.male? kActive_CardColor : kInactive_CardColor,
                      cardChild: Male_femle_child(icon: FontAwesomeIcons.mars, text: 'Male',),
                  ),
                ),
                Expanded(
                  child: LayoutContainer(
                    onpress: (){
                      setState(() {
                        selectedGender = gender.female;
                      });
                    },
                    colour: selectedGender == gender.female ? kActive_CardColor : kInactive_CardColor,
                    cardChild: Male_femle_child(icon: FontAwesomeIcons.venus, text: 'Female',),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: LayoutContainer(
                colour: kActive_CardColor,
                cardChild: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('Height', style: kLabel_text_style,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.baseline,
                      textBaseline: TextBaseline.alphabetic,
                      children: [
                        Text(height.toString(), style: knumber_text_style,),
                        Text('cm', style: kLabel_text_style,),
                      ],
                    ),
                    SliderTheme(
                      data: SliderTheme.of(context).copyWith(
                        thumbColor: Color(0xFFEB1555),
                        activeTrackColor: Color(0xFFfdfcff),
                        overlayColor: Color(0x37E76B92),
                        thumbShape: RoundSliderThumbShape(enabledThumbRadius: 15),
                        overlayShape: RoundSliderOverlayShape(overlayRadius: 30.0),
                      ),
                      child: Slider(
                          value: height.toDouble(),
                          min: 120.0,
                          max: 220.0,
                          inactiveColor: Color(0xFF8D8E98),
                          onChanged: (double newvalue){
                              setState(() {
                                height = newvalue.round();
                              });
                          }
                      ),
                    )
                  ],
                ),
            ),
          ),
          //--------------ROW
          Expanded(
            child: Row(
              children: [
                Expanded(
                  child: LayoutContainer(
                    colour: kActive_CardColor,
                    cardChild: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('Weight', style: kLabel_text_style,),
                        Text(weight.toString(), style: knumber_text_style,),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            RoundIconButton(
                              icon: Icon(FontAwesomeIcons.minus,size: 32,),
                              action: (){
                                setState(() {
                                  weight--;
                                });
                              },
                            ),
                            SizedBox(width: 10,),
                            RoundIconButton(
                              icon: Icon(FontAwesomeIcons.plus,size: 32,),
                              action: (){
                                setState(() {
                                  weight++;
                                });
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: LayoutContainer(
                    colour: kActive_CardColor,
                    cardChild: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                          Text('Age',style: kLabel_text_style,),
                          Text(age.toString(), style: knumber_text_style,),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              RoundIconButton(
                                icon: Icon(FontAwesomeIcons.minus, size: 32,),
                                action: (){
                                  setState(() {
                                    age--;
                                  });
                                },
                              ),
                              SizedBox(width: 10,),
                              RoundIconButton(
                                icon: Icon(FontAwesomeIcons.plus,size: 32,),
                                action: (){
                                  setState(() {
                                    age++;
                                  });
                                },
                              ),
                            ],
                          )
                    ],
                  ),),
                ),
              ],
            ),
          ),
          BottomButton(
            butttonText: 'Calculate',
            ontap: (){
              Bmibrain brain =Bmibrain(height: height, weight: weight);
              Navigator.push(context, MaterialPageRoute(builder: (context){
                return ResultPage(Bmi_result: brain.calc_result(), Bmi_status: brain.get_status(), Bmi_des: brain.result_des(),);
            }),);
            },
          ),
        ],
      ),
    );
  }
}









