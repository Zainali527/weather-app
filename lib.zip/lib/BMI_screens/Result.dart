import 'package:course/BMI_components/BottomButton.dart';
import 'package:course/BMI_components/Const_varibles.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import '../BMI_components/Layout_container.dart';
class ResultPage extends StatelessWidget {
  final String Bmi_result;
  final String Bmi_status;
  final String Bmi_des;
  ResultPage({required this.Bmi_result, required this.Bmi_status, required this.Bmi_des});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('BMI Calculator'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: Container(
              padding: EdgeInsets.all(15.0),
                alignment: Alignment.bottomLeft,
                child: Text('Your Result',style: TextStyle(fontWeight: FontWeight.w700, fontSize: 48),)),
          ),
          Expanded(
            flex: 5,
            child: LayoutContainer(
              colour: kActive_CardColor,
              cardChild: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(Bmi_status, style: kResultColor,),
                  Text(Bmi_result,style: knumber_text_style,),
                  Text(Bmi_des, textAlign: TextAlign.center,style: kLabel_text_style,)
                ],
              ),
            )
          ),
          Expanded(
            child: BottomButton(
                butttonText: 'Re-Calculate',
                ontap: (){
                  Navigator.pop(context);
                },
            ),
          ),
        ],
      ),
    );
  }
}
