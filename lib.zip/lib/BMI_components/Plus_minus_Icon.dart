import 'package:flutter/material.dart';
class RoundIconButton extends StatelessWidget {
  final Icon icon;
  final VoidCallback? action;
  RoundIconButton({required this.icon, this.action});

  @override
  Widget build(BuildContext context) {
    return RawMaterialButton(
      shape: CircleBorder(),
      elevation: 12.0,
      constraints: BoxConstraints.tightFor(
        width: 56.0,
        height: 56.0,
      ),
      fillColor: Color(0xFF4C4F5E),
      onPressed: action,
      child: icon,
    );
  }
}