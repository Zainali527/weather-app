import 'dart:math';
double _bmi=0;
class Bmibrain {
  final int height;
  final int weight;
  Bmibrain({required this.height, required this.weight});
  String calc_result(){
    _bmi = weight / pow(height/100, 2);
    return _bmi.toStringAsFixed(1);
  }
  String get_status (){
    if(_bmi>=25){
      return 'Overweight';
    }
    else if(_bmi>18.5){
      return 'Normal';
    }
    else{
      return 'Underweight';
    }
  }

  String result_des (){
    if(_bmi>=25){
      return 'You have a higher than normal body weight, Try to exercise daily';
    }
    else if(_bmi>18.5){
      return 'You have a normal body weight';
    }
    else{
      return 'You have a lower than normal body weight, You should eat properly';
    }
  }
}