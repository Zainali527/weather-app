import 'package:flutter/material.dart';
import 'Const_varibles.dart';

class Male_femle_child extends StatelessWidget {
  final IconData icon;
  final String text;
  Male_femle_child({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(
          icon,
          size: 80,
        ),
        SizedBox(height: 15,),
        Text(
          text,
          style: kLabel_text_style,
        ),
      ],
    );
  }
}