import 'package:flutter/material.dart';
import 'Const_varibles.dart';
class BottomButton extends StatelessWidget {
  final String butttonText;
  final VoidCallback? ontap;
  BottomButton({required this.butttonText, this.ontap});
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: ontap,
      child: Container(
        child: Center(child: Text(butttonText,style: kcalculate_button,)),
        height: kButtonContainer,
        width: double.infinity,
        decoration: BoxDecoration(
          color: kLayout_BottonContainerColor,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20.0),
            topRight: Radius.circular(20.0),
            bottomLeft: Radius.circular(20.0),
            bottomRight: Radius.circular(20.0),
          ),
        ),
      ),
    );
  }
}