class Questions {
  String ques;
  bool ans;
  Questions({
    required this.ques,
    required this.ans,
});
}